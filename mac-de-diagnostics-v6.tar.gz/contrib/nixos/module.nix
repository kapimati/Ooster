# Użycie (klasyczny configuration.nix, bez flake'ów):
#
#   imports = [ /sciezka/do/mac-de/module.nix ];
#   programs.mac-de.enable = true;
#
# Potem wybierz sesję "Mac DE" w menedżerze logowania.
{ config, lib, pkgs, ... }:

let
  cfg = config.programs.mac-de;
  mac-de = pkgs.callPackage ./default.nix { };

  session = pkgs.writeShellScriptBin "mac-de-session" ''
    export XDG_CURRENT_DESKTOP=MacDE
    export XDG_SESSION_DESKTOP=MacDE
    export XDG_SESSION_TYPE=wayland
    export QT_QPA_PLATFORM=wayland
    exec ${pkgs.dbus}/bin/dbus-run-session \
      ${pkgs.kdePackages.kwin}/bin/kwin_wayland --xwayland \
      --exit-with-session=${mac-de}/bin/mac-de
  '';

  sessionEntry = (pkgs.writeTextDir "share/wayland-sessions/mac-de.desktop" ''
    [Desktop Entry]
    Name=Mac DE
    Comment=Powłoka w stylu macOS na KWin
    Exec=${session}/bin/mac-de-session
    Type=Application
  '').overrideAttrs (_: { passthru.providedSessions = [ "mac-de" ]; });
in
{
  options.programs.mac-de.enable = lib.mkEnableOption "środowisko Mac DE (Rust + Qt/KWin)";

  config = lib.mkIf cfg.enable {
    environment.systemPackages = [
      mac-de
      pkgs.kdePackages.kwin
      pkgs.kdePackages.breeze-icons
      pkgs.kdePackages.dolphin
      pkgs.kdePackages.konsole
    ];

    # Na NixOS < 24.11 użyj: services.xserver.displayManager.sessionPackages
    services.displayManager.sessionPackages = [ sessionEntry ];

    security.polkit.enable = true;
    hardware.graphics.enable = true;
  };
}
