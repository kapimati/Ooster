{ lib, rustPlatform, pkg-config, qt6 }:

rustPlatform.buildRustPackage {
  pname = "mac-de";
  version = "0.1.0";

  src = lib.cleanSource ../..;
  cargoLock.lockFile = ../../Cargo.lock;

  nativeBuildInputs = [ pkg-config qt6.wrapQtAppsHook ];
  buildInputs = [ qt6.qtbase qt6.qtdeclarative qt6.qtwayland ];

  # cxx-qt-build szuka qmake
  env.QMAKE = "${qt6.qtbase}/bin/qmake";

  meta = {
    description = "Powłoka w stylu macOS (dock + górny pasek) na Qt/QML, pisana w Rust";
    mainProgram = "mac-de";
    platforms = lib.platforms.linux;
  };
}
