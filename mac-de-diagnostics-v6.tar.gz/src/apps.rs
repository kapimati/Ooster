//! Backend docka: lista aplikacji z plików .desktop i uruchamianie.

use std::{collections::HashSet, env, fs, path::PathBuf, process::Command};

#[cxx_qt::bridge]
pub mod qobject {
    unsafe extern "C++" {
        include!("cxx-qt-lib/qstring.h");
        type QString = cxx_qt_lib::QString;
    }

    unsafe extern "RustQt" {
        #[qobject]
        #[qml_element]
        type AppLauncher = super::AppLauncherRust;
    }

    unsafe extern "RustQt" {
        /// Uruchamia polecenie (bez powłoki).
        #[qinvokable]
        fn launch(self: &AppLauncher, command: &QString) -> bool;

        /// Zwraca JSON z aplikacjami przypiętymi do docka.
        #[qinvokable]
        fn favorites(self: &AppLauncher) -> QString;

        /// Zwraca wszystkie widoczne aplikacje dla Launchpada.
        #[qinvokable]
        fn applications(self: &AppLauncher) -> QString;
    }
}

use cxx_qt_lib::QString;

#[derive(Default)]
pub struct AppLauncherRust;

struct Entry {
    name: String,
    icon: String,
    exec: String,
}

/// Ulubione (kolejność w docku); brakujące są pomijane.
const FAVORITES: &[&str] = &[
    "org.kde.dolphin",
    "firefox",
    "org.kde.konsole",
    "org.kde.kate",
    "systemsettings",
];

fn app_dirs() -> Vec<PathBuf> {
    let mut dirs = Vec::new();
    if let Some(home) = env::var_os("XDG_DATA_HOME") {
        dirs.push(PathBuf::from(home).join("applications"));
    } else if let Some(home) = env::var_os("HOME") {
        dirs.push(PathBuf::from(home).join(".local/share/applications"));
    }
    let data_dirs = env::var("XDG_DATA_DIRS")
        .unwrap_or_else(|_| "/usr/local/share:/usr/share".to_string());
    for d in data_dirs.split(':').filter(|d| !d.is_empty()) {
        dirs.push(PathBuf::from(d).join("applications"));
    }
    dirs.push(PathBuf::from("/run/current-system/sw/share/applications"));
    dirs
}

/// Parser podstawowych pól sekcji [Desktop Entry], z preferencją dla języka systemu.
fn parse_desktop(text: &str) -> Option<Entry> {
    let (mut name, mut localized_name, mut icon, mut exec) = (None, None, String::new(), None);
    let (mut in_main, mut hidden, mut kind_ok, mut terminal) = (false, false, true, false);
    let mut try_exec: Option<String> = None;
    let current_desktop = env::var("XDG_CURRENT_DESKTOP").unwrap_or_default();

    for line in text.lines() {
        let line = line.trim();
        if line.starts_with('[') {
            in_main = line == "[Desktop Entry]";
            continue;
        }
        if !in_main || line.is_empty() || line.starts_with('#') { continue; }
        let Some((k, v)) = line.split_once('=') else { continue };
        match k {
            "Name" => name = Some(v.to_string()),
            "Name[pl]" => localized_name = Some(v.to_string()),
            "Icon" => icon = v.to_string(),
            "Exec" => exec = Some(clean_exec(v)),
            "TryExec" => try_exec = Some(v.to_string()),
            "NoDisplay" | "Hidden" => hidden |= v.eq_ignore_ascii_case("true"),
            "Terminal" => terminal = v.eq_ignore_ascii_case("true"),
            "Type" => kind_ok = v == "Application",
            "OnlyShowIn" => {
                let allowed: Vec<&str> = v.split(';').filter(|x| !x.is_empty()).collect();
                if !allowed.is_empty() && !current_desktop.is_empty()
                    && !current_desktop.split(':').any(|d| allowed.contains(&d)) {
                    hidden = true;
                }
            }
            _ => {}
        }
    }
    if hidden || !kind_ok || terminal { return None; }
    if let Some(value) = try_exec.as_deref() {
        // TryExec może zawierać argumenty; sprawdzamy tylko plik wykonywalny.
        let bin = split_exec(value).into_iter().next().unwrap_or_default();
        if !bin.is_empty() && !command_exists(&bin) { return None; }
    }
    let exec = exec?;
    if split_exec(&exec).is_empty() { return None; }
    Some(Entry { name: localized_name.or(name)?, icon, exec })
}

fn command_exists(command: &str) -> bool {
    let path = PathBuf::from(command);
    if path.components().count() > 1 { return path.is_file(); }
    env::var_os("PATH").into_iter().flat_map(|p| env::split_paths(&p).collect::<Vec<_>>())
        .any(|dir| dir.join(command).is_file())
}

/// Tokenizuje pole Exec zgodnie z typowym cytowaniem desktop-entry; nie uruchamia powłoki.
fn split_exec(input: &str) -> Vec<String> {
    let mut args = Vec::new();
    let mut token = String::new();
    let mut quoted = false;
    let mut escaped = false;
    let mut active = false;
    for ch in input.chars() {
        if escaped {
            token.push(ch);
            escaped = false;
            active = true;
        } else if ch == '\\' && quoted {
            escaped = true;
        } else if ch == '"' {
            quoted = !quoted;
            active = true;
        } else if ch.is_whitespace() && !quoted {
            if active { args.push(std::mem::take(&mut token)); active = false; }
        } else {
            token.push(ch);
            active = true;
        }
    }
    if escaped { token.push('\\'); }
    if active { args.push(token); }

    args.into_iter().filter_map(|arg| {
        if arg.len() == 2 && arg.starts_with('%') {
            // Pola podstawiane przez launcher (pliki/URI/pozycja) nie są potrzebne dla docka.
            if "fFuUdDnNickvm".contains(arg.chars().nth(1).unwrap_or(' ')) { return None; }
            if arg == "%%" { return Some("%".to_string()); }
        }
        Some(arg.replace("%%", "%"))
    }).collect()
}

/// Normalizuje Exec do bezpiecznej, ponownie parsowalnej listy argumentów.
fn clean_exec(exec: &str) -> String {
    split_exec(exec).iter().map(|arg| {
        if arg.chars().any(char::is_whitespace) || arg.contains('"') || arg.contains('\\') {
            format!("\"{}\"", arg.replace('\\', "\\\\").replace('"', "\\\""))
        } else { arg.clone() }
    }).collect::<Vec<_>>().join(" ")
}

fn load_entry(id: &str, dirs: &[PathBuf]) -> Option<Entry> {
    dirs.iter()
        .find_map(|d| fs::read_to_string(d.join(format!("{id}.desktop"))).ok())
        .and_then(|t| parse_desktop(&t))
}

fn json_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}

fn entries_json(entries: &[Entry]) -> String {
    let items: Vec<String> = entries
        .iter()
        .map(|e| format!(
            "{{\"name\":\"{}\",\"icon\":\"{}\",\"exec\":\"{}\"}}",
            json_escape(&e.name), json_escape(&e.icon), json_escape(&e.exec)
        ))
        .collect();
    format!("[{}]", items.join(","))
}

fn favorites_json() -> String {
    let dirs = app_dirs();
    let mut entries: Vec<Entry> = FAVORITES
        .iter()
        .filter_map(|id| load_entry(id, &dirs))
        .collect();

    // Gdy ulubionych brakuje (np. inna dystrybucja), dobierz inne aplikacje.
    if entries.len() < 3 {
        let mut seen: HashSet<String> = entries.iter().map(|e| e.name.clone()).collect();
        'outer: for d in &dirs {
            let Ok(rd) = fs::read_dir(d) else { continue };
            let mut files: Vec<_> = rd.flatten().map(|e| e.path()).collect();
            files.sort();
            for p in files {
                if p.extension().and_then(|e| e.to_str()) != Some("desktop") {
                    continue;
                }
                if let Some(e) = fs::read_to_string(&p).ok().and_then(|t| parse_desktop(&t)) {
                    if seen.insert(e.name.clone()) {
                        entries.push(e);
                    }
                }
                if entries.len() >= 6 {
                    break 'outer;
                }
            }
        }
    }

    entries_json(&entries)
}

fn applications_json() -> String {
    let dirs = app_dirs();
    let mut by_name = std::collections::BTreeMap::<String, Entry>::new();
    for dir in &dirs {
        let Ok(rd) = fs::read_dir(dir) else { continue };
        let mut files: Vec<_> = rd.flatten().map(|e| e.path()).collect();
        files.sort();
        for path in files {
            if path.extension().and_then(|e| e.to_str()) != Some("desktop") { continue; }
            let Ok(contents) = fs::read_to_string(&path) else { continue };
            let Some(entry) = parse_desktop(&contents) else { continue };
            by_name.entry(entry.name.to_lowercase()).or_insert(entry);
        }
    }
    let mut entries: Vec<Entry> = by_name.into_values().collect();
    entries.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
    entries_json(&entries)
}

impl qobject::AppLauncher {
    pub fn launch(&self, command: &QString) -> bool {
        let command = command.to_string();
        let parts = split_exec(&command);
        let Some((program, args)) = parts.split_first() else {
            eprintln!("mac-de: puste pole Exec — nie można uruchomić aplikacji");
            return false;
        };
        eprintln!("mac-de: uruchamiam aplikację: {program} {args:?}");
        match Command::new(program).args(args).spawn() {
            Ok(child) => {
                eprintln!("mac-de: proces uruchomiony (pid {})", child.id());
                true
            },
            Err(error) => {
                eprintln!("mac-de: nie udało się uruchomić {program}: {error}");
                false
            },
        }
    }

    pub fn favorites(&self) -> QString {
        QString::from(&favorites_json())
    }

    pub fn applications(&self) -> QString {
        QString::from(&applications_json())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_basic_entry() {
        let e = parse_desktop(
            "[Desktop Entry]\nType=Application\nName=Konsole\nIcon=utilities-terminal\nExec=konsole %u\n[Desktop Action x]\nName=Inne\n",
        )
        .unwrap();
        assert_eq!(e.name, "Konsole");
        assert_eq!(e.exec, "konsole");
    }

    #[test]
    fn preserves_quoted_arguments() {
        let e = parse_desktop("[Desktop Entry]\nType=Application\nName=Test\nExec=app --title \"Hello World\" %U\n").unwrap();
        assert_eq!(split_exec(&e.exec), vec!["app", "--title", "Hello World"]);
    }

    #[test]
    fn skips_terminal_apps() {
        assert!(parse_desktop("[Desktop Entry]\nName=CLI\nExec=cli\nTerminal=true\n").is_none());
    }

    #[test]
    fn skips_hidden() {
        assert!(parse_desktop("[Desktop Entry]\nName=X\nExec=x\nNoDisplay=true\n").is_none());
    }

    #[test]
    fn escapes_json() {
        assert_eq!(json_escape("a\"b\\c"), "a\\\"b\\\\c");
    }
}
