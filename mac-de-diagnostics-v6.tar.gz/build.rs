use cxx_qt_build::{CxxQtBuilder, QmlModule};

fn main() {
    CxxQtBuilder::new()
        .qt_module("Qml")
        .qt_module("Quick")
        .qml_module(QmlModule {
            uri: "org.macde.shell",
            rust_files: &["src/apps.rs"],
            qml_files: &[
                "qml/main.qml",
                "qml/TopBarView.qml",
                "qml/DockView.qml",
                "qml/PowerMenuView.qml",
                "qml/BarWindow.qml",
                "qml/DockWindow.qml",
                "qml/MenuWindow.qml",
                "qml/LaunchpadWindow.qml",
                "qml/LayerLaunchpadWindow.qml",
                "qml/LayerBarWindow.qml",
                "qml/LayerDockWindow.qml",
                "qml/LayerMenuWindow.qml",
            ],
            ..Default::default()
        })
        .build();
}
