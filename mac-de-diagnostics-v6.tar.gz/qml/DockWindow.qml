import QtQuick

Window {
    id: win
    property bool plain: true

    flags: plain ? (Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus) : Qt.Window
    width: dock.implicitWidth
    height: dock.implicitHeight
    x: (Screen.width - width) / 2
    y: Screen.height - height
    color: "transparent"
    visible: true

    DockView { id: dock; anchors.fill: parent }
}
