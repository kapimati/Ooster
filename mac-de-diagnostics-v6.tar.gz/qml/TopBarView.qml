import QtQuick
import QtQuick.Controls

Rectangle {
    id: root
    signal menuClicked()
    signal launcherClicked()
    implicitHeight: 34
    color: Qt.rgba(0.075, 0.082, 0.105, 0.94)
    border.width: 0

    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: 1
        color: Qt.rgba(1, 1, 1, 0.13)
    }

    Row {
        anchors { left: parent.left; leftMargin: 16; verticalCenter: parent.verticalCenter }
        spacing: 17

        Label {
            text: "⌘"
            color: "white"
            font.pixelSize: 18
            font.bold: true
            verticalAlignment: Text.AlignVCenter
            MouseArea {
                anchors.fill: parent
                anchors.margins: -8
                cursorShape: Qt.PointingHandCursor
                onClicked: root.menuClicked()
            }
        }
        Label { text: "Mac DE"; color: "white"; font.bold: true; font.pixelSize: 13 }
        Label { text: "Plik"; color: "#e4e7ed"; font.pixelSize: 13 }
        Label { text: "Edycja"; color: "#e4e7ed"; font.pixelSize: 13 }
        Label { text: "Widok"; color: "#e4e7ed"; font.pixelSize: 13 }
        Label { text: "Okno"; color: "#e4e7ed"; font.pixelSize: 13 }
        Rectangle {
            width: 1; height: 16; color: Qt.rgba(1, 1, 1, 0.18)
            anchors.verticalCenter: parent.verticalCenter
        }
        Label {
            text: "Aplikacje"; color: launchHit.containsMouse ? "white" : "#c8ceda"
            font.pixelSize: 13
            MouseArea {
                id: launchHit; anchors.fill: parent; anchors.margins: -7
                hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                onClicked: { console.info("mac-de: kliknięto Aplikacje w pasku"); root.launcherClicked() }
            }
        }
    }

    Row {
        anchors { right: parent.right; rightMargin: 16; verticalCenter: parent.verticalCenter }
        spacing: 12
        Label {
            id: clock
            color: "white"
            font.pixelSize: 12
            text: Qt.formatDateTime(new Date(), "ddd d MMM  HH:mm")
            Timer {
                interval: 15000
                running: true
                repeat: true
                onTriggered: clock.text = Qt.formatDateTime(new Date(), "ddd d MMM  HH:mm")
            }
        }
    }
}
