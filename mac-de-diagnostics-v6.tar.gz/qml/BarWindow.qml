import QtQuick

// Górny pasek jako zwykłe okno. Wersja layer-shell (LayerBarWindow) dziedziczy po tym pliku.
Window {
    id: win
    property bool plain: true
    signal menuClicked()
    signal launcherClicked()

    flags: plain ? (Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus) : Qt.Window
    x: 0; y: 0
    width: Screen.width
    height: bar.implicitHeight
    color: "transparent"
    visible: true

    TopBarView {
        id: bar
        anchors.fill: parent
        onMenuClicked: win.menuClicked()
        onLauncherClicked: win.launcherClicked()
    }
}
