import QtQuick

// Pełnoekranowa, przezroczysta nakładka z menu systemowym.
Window {
    id: win
    property bool plain: true
    signal closeRequested()

    flags: plain ? (Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint) : Qt.Window
    x: 0; y: 0
    width: Screen.width
    height: Screen.height
    color: "transparent"
    visible: false

    PowerMenuView { anchors.fill: parent; onCloseRequested: win.closeRequested() }
}
