import QtQuick
import QtQuick.Controls
import org.macde.shell

Item {
    id: root
    signal closeRequested()
    AppLauncher { id: launcher }

    MouseArea {
        anchors.fill: parent
        onClicked: root.closeRequested()
    }

    Rectangle {
        id: card
        x: 12
        y: 42
        width: 258
        height: content.implicitHeight + 24
        radius: 16
        color: Qt.rgba(0.075, 0.085, 0.11, 0.98)
        border.width: 1
        border.color: Qt.rgba(1, 1, 1, 0.17)

        MouseArea { anchors.fill: parent; onClicked: {} }

        Column {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12 }
            spacing: 5

            Row {
                spacing: 10
                Rectangle {
                    width: 38; height: 38; radius: 11
                    color: Qt.rgba(1, 1, 1, 0.10)
                    Label { anchors.centerIn: parent; text: "⌘"; color: "white"; font.pixelSize: 22 }
                }
                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    Label { text: "Mac DE"; color: "white"; font.pixelSize: 14; font.bold: true }
                    Label { text: "Ustawienia sesji"; color: "#aeb6c6"; font.pixelSize: 11 }
                }
            }

            Rectangle { width: parent.width; height: 1; color: Qt.rgba(1, 1, 1, 0.12) }

            component Entry: Rectangle {
                property string labelText: ""
                property string glyph: ""
                signal triggered()
                width: 232
                height: 34
                radius: 8
                color: hit.containsMouse ? Qt.rgba(0.20, 0.43, 0.83, 0.92) : "transparent"
                Row {
                    anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                    spacing: 10
                    Label { text: glyph; color: "white"; width: 18; anchors.verticalCenter: parent.verticalCenter; horizontalAlignment: Text.AlignHCenter }
                    Label { text: labelText; color: "white"; anchors.verticalCenter: parent.verticalCenter; font.pixelSize: 13 }
                }
                MouseArea {
                    id: hit
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: parent.triggered()
                }
                Behavior on color { ColorAnimation { duration: 100 } }
            }

            Entry { glyph: "◌"; labelText: "Uśpij"; onTriggered: { launcher.launch("systemctl suspend"); root.closeRequested() } }
            Entry { glyph: "↻"; labelText: "Uruchom ponownie"; onTriggered: launcher.launch("systemctl reboot") }
            Entry { glyph: "⏻"; labelText: "Wyłącz komputer"; onTriggered: launcher.launch("systemctl poweroff") }
            Rectangle { width: parent.width; height: 1; color: Qt.rgba(1, 1, 1, 0.12) }
            Entry { glyph: "⇥"; labelText: "Wyloguj"; onTriggered: Qt.quit() }
        }
    }
}
