import QtQuick
import org.kde.layershell 1.0 as LayerShell

// Pasek jako panel layer-shell: przypięty do góry, rezerwuje swoją wysokość.
BarWindow {
    plain: false
    LayerShell.Window.scope: "mac-de-topbar"
    LayerShell.Window.layer: LayerShell.Window.LayerTop
    LayerShell.Window.anchors: LayerShell.Window.AnchorTop | LayerShell.Window.AnchorLeft | LayerShell.Window.AnchorRight
    LayerShell.Window.exclusionZone: height
    LayerShell.Window.keyboardInteractivity: LayerShell.Window.KeyboardInteractivityNone
}
