import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.macde.shell

// Full-screen launcher overlay. Uses desktop entries supplied by the Rust backend.
Window {
    id: win
    property bool plain: true
    signal closeRequested()

    flags: plain ? (Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint) : Qt.Window
    x: 0
    y: 0
    width: Screen.width
    height: Screen.height
    color: "transparent"
    visible: false
    title: "Mac DE — Aplikacje"

    AppLauncher { id: launcher }
    Shortcut {
        sequence: "Escape"
        context: Qt.ApplicationShortcut
        onActivated: win.closeRequested()
    }
    property var allApps: []
    property string launchError: ""

    function reloadApps() {
        try {
            var result = JSON.parse(launcher.applications())
            allApps = result
            console.info("mac-de: Launchpad załadował", allApps.length, "aplikacji")
        } catch (e) {
            console.warn("mac-de: nie udało się wczytać aplikacji:", e)
            allApps = []
        }
    }

    function launchApp(exec, name) {
        console.info("mac-de: kliknięto aplikację:", name, "Exec:", exec)
        if (launcher.launch(exec)) {
            launchError = ""
            closeRequested()
        } else {
            launchError = "Nie udało się uruchomić: " + name
            console.warn("mac-de: uruchomienie aplikacji nie powiodło się:", name)
        }
    }

    function filteredApps() {
        var q = searchField.text.trim().toLocaleLowerCase()
        if (!q) return allApps
        return allApps.filter(function (app) {
            return app.name.toLocaleLowerCase().indexOf(q) !== -1
        })
    }

    onVisibleChanged: {
        if (visible) {
            reloadApps()
            searchField.text = ""
            launchError = ""
            searchField.forceActiveFocus()
        }
    }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0.025, 0.03, 0.05, 0.58)
        MouseArea { anchors.fill: parent; onClicked: win.closeRequested() }
    }

    Rectangle {
        id: panel
        width: Math.min(parent.width - 40, 900)
        height: Math.min(parent.height - 80, 700)
        anchors.centerIn: parent
        radius: 28
        color: Qt.rgba(0.105, 0.115, 0.15, 0.97)
        border.width: 1
        border.color: Qt.rgba(1, 1, 1, 0.19)

        MouseArea { anchors.fill: parent; onClicked: {} }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 26
            spacing: 18

            RowLayout {
                Layout.fillWidth: true
                Label {
                    text: "Aplikacje"
                    color: "white"
                    font.pixelSize: 26
                    font.weight: Font.DemiBold
                    Layout.fillWidth: true
                }
                ToolButton {
                    text: "✕"
                    onClicked: win.closeRequested()
                    ToolTip.visible: hovered
                    ToolTip.text: "Zamknij"
                }
            }

            TextField {
                id: searchField
                Layout.fillWidth: true
                placeholderText: "Szukaj aplikacji…"
                selectByMouse: true
                color: "white"
                font.pixelSize: 15
                leftPadding: 42
                background: Rectangle {
                    radius: 13
                    color: Qt.rgba(1, 1, 1, 0.075)
                    border.width: searchField.activeFocus ? 2 : 1
                    border.color: searchField.activeFocus ? "#7da7ff" : Qt.rgba(1, 1, 1, 0.13)
                }
                Label {
                    text: "⌕"
                    color: "#b9c2d3"
                    font.pixelSize: 24
                    anchors.left: parent.left
                    anchors.leftMargin: 13
                    anchors.verticalCenter: parent.verticalCenter
                }
                Keys.onEscapePressed: win.closeRequested()
                Keys.onReturnPressed: {
                    var matches = win.filteredApps()
                    if (matches.length > 0)
                        win.launchApp(matches[0].exec, matches[0].name)
                }
            }

            Label {
                Layout.fillWidth: true
                text: win.launchError !== "" ? win.launchError : (grid.count === 0 ? "Brak pasujących aplikacji" : (grid.count + " aplikacji"))
                color: win.launchError !== "" ? "#ff9b9b" : "#aeb8ca"
                font.pixelSize: 12
                elide: Text.ElideRight
            }

            GridView {
                id: grid
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                cellWidth: 126
                cellHeight: 116
                model: win.filteredApps()
                ScrollBar.vertical: ScrollBar { active: true }

                delegate: Item {
                    required property var modelData
                    width: grid.cellWidth
                    height: grid.cellHeight

                    ToolButton {
                        id: appButton
                        anchors.fill: parent
                        anchors.margins: 5
                        padding: 8
                        display: AbstractButton.TextUnderIcon
                        icon.name: modelData.icon || "application-x-executable"
                        icon.width: 44
                        icon.height: 44
                        text: modelData.name
                        font.pixelSize: 12
                        font.weight: Font.Medium
                        icon.color: "white"
                        background: Rectangle {
                            radius: 15
                            color: appButton.hovered ? Qt.rgba(1, 1, 1, 0.11) : "transparent"
                            border.width: appButton.hovered ? 1 : 0
                            border.color: Qt.rgba(1, 1, 1, 0.12)
                            Behavior on color { ColorAnimation { duration: 110 } }
                        }
                        onClicked: win.launchApp(modelData.exec, modelData.name)
                        ToolTip.visible: hovered
                        ToolTip.text: modelData.name
                    }
                }
            }
        }
    }
}
