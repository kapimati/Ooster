import QtQuick

// Na Waylandzie próbujemy prawdziwych paneli (layer-shell, pliki Layer*.qml).
// Gdy wtyczki org.kde.layershell brak (pakiet layer-shell-qt), X11 albo test offscreen:
// spadamy do zwykłych okien bez ramek.
QtObject {
    id: app
    property var bar: null
    property var dock: null
    property var menu: null
    property var launchpad: null

    function load(prefix) {
        var names = ["BarWindow", "DockWindow", "MenuWindow", "LaunchpadWindow"];
        var comps = [];
        for (var i = 0; i < names.length; i++) {
            var url = Qt.resolvedUrl(prefix + names[i] + ".qml");
            var c = Qt.createComponent(url, Component.PreferSynchronous);
            if (c.status !== Component.Ready) {
                console.warn("mac-de: nie można załadować komponentu", url, "status:", c.status, c.errorString());
                return false;
            }
            comps.push(c);
        }
        // Bez rodzica: okna najwyższego poziomu. Sprzątaj częściowo utworzone okna,
        // jeśli którykolwiek komponent nie może się utworzyć.
        bar = comps[0].createObject(null);
        dock = comps[1].createObject(null);
        menu = comps[2].createObject(null);
        launchpad = comps[3].createObject(null);
        if (!bar || !dock || !menu || !launchpad) {
            console.warn("mac-de: nie udało się utworzyć wszystkich okien",
                         bar ? "" : "bar", dock ? "" : "dock", menu ? "" : "menu", launchpad ? "" : "launchpad");
            if (bar) bar.destroy();
            if (dock) dock.destroy();
            if (menu) menu.destroy();
            if (launchpad) launchpad.destroy();
            bar = null; dock = null; menu = null; launchpad = null;
            return false;
        }
        // Podłączaj sygnały dopiero po utworzeniu wszystkich okien.
        // BarWindow przekazuje teraz launcherClicked z TopBarView, więc kliknięcie
        // „Aplikacje” nie przerywa konfiguracji pozostałych połączeń.
        bar.menuClicked.connect(function () {
            console.info("mac-de: kliknięto menu systemowe");
            menu.visible = !menu.visible;
            if (menu.visible) menu.raise();
        });
        menu.closeRequested.connect(function () { menu.visible = false; });
        bar.launcherClicked.connect(function () {
            console.info("mac-de: kliknięto przycisk Aplikacje");
            var show = !launchpad.visible;
            if (show && launchpad.reloadApps)
                launchpad.reloadApps();
            launchpad.visible = show;
            if (show) {
                launchpad.raise();
                launchpad.requestActivate();
            }
        });
        launchpad.closeRequested.connect(function () { console.info("mac-de: zamykam Launchpad"); launchpad.visible = false; });
        return true;
    }

    Component.onCompleted: {
        var wayland = Qt.platform.pluginName.indexOf("wayland") === 0;
        if (wayland && load("Layer"))
            return;
        if (wayland)
            console.warn("mac-de: tryb zapasowy (zwykłe okna); zainstaluj layer-shell-qt");
        load("");
    }
}
