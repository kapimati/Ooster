import QtQuick
import QtQuick.Controls
import org.macde.shell

Item {
    id: root
    implicitWidth: Math.min(Screen.width - 24, Math.max(250, row.implicitWidth + 36))
    implicitHeight: 94
    property var apps: []

    Component.onCompleted: {
        try { apps = JSON.parse(launcher.favorites()) }
        catch (e) { console.warn("mac-de: nie udało się wczytać ulubionych:", e) }
    }

    AppLauncher { id: launcher }
    HoverHandler { id: hover }

    Rectangle {
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; bottomMargin: 5 }
        height: 70
        radius: 23
        color: Qt.rgba(0.075, 0.085, 0.115, 0.86)
        border.width: 1
        border.color: Qt.rgba(1, 1, 1, 0.22)

        Rectangle {
            anchors { left: parent.left; right: parent.right; top: parent.top; leftMargin: 18; rightMargin: 18 }
            height: 1
            color: Qt.rgba(1, 1, 1, 0.14)
        }
    }

    Row {
        id: row
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 15 }
        spacing: 8

        Repeater {
            model: root.apps
            delegate: Item {
                id: cell
                width: 50
                height: 58
                property real magnification: {
                    if (!hover.hovered) return 1.0
                    var center = row.x + cell.x + cell.width / 2
                    var distance = hover.point.position.x - center
                    return 1.0 + 0.38 * Math.exp(-(distance * distance) / (2 * 60 * 60))
                }

                ToolButton {
                    id: appButton
                    width: 54
                    height: 54
                    anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom }
                    padding: 3
                    icon.name: modelData.icon || "application-x-executable"
                    icon.width: 46
                    icon.height: 46
                    background: Rectangle {
                        radius: 13
                        color: appButton.hovered ? Qt.rgba(1, 1, 1, 0.13) : "transparent"
                        Behavior on color { ColorAnimation { duration: 120 } }
                    }
                    scale: cell.magnification
                    transformOrigin: Item.Bottom
                    Behavior on scale { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
                    ToolTip.visible: hovered
                    ToolTip.text: modelData.name
                    ToolTip.delay: 450
                    onClicked: {
                        console.info("mac-de: kliknięto ikonę docka:", modelData.name)
                        if (!launcher.launch(modelData.exec))
                            console.warn("mac-de: nie udało się uruchomić aplikacji z docka:", modelData.name)
                    }
                }
            }
        }
    }
}
