import QtQuick
import org.kde.layershell 1.0 as LayerShell

// Nakładka na cały ekran nad wszystkim; nie rezerwuje miejsca (-1).
MenuWindow {
    plain: false
    LayerShell.Window.scope: "mac-de-menu"
    LayerShell.Window.layer: LayerShell.Window.LayerOverlay
    LayerShell.Window.anchors: LayerShell.Window.AnchorTop | LayerShell.Window.AnchorBottom | LayerShell.Window.AnchorLeft | LayerShell.Window.AnchorRight
    LayerShell.Window.exclusionZone: -1
    LayerShell.Window.keyboardInteractivity: LayerShell.Window.KeyboardInteractivityNone
}
