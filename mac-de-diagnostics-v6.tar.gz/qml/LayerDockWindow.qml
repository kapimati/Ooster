import QtQuick
import org.kde.layershell 1.0 as LayerShell

// Dock przypięty do dołu (bez kotwicy poziomej = wyśrodkowany), rezerwuje swoją wysokość.
DockWindow {
    plain: false
    LayerShell.Window.scope: "mac-de-dock"
    LayerShell.Window.layer: LayerShell.Window.LayerTop
    LayerShell.Window.anchors: LayerShell.Window.AnchorBottom
    LayerShell.Window.exclusionZone: height
    LayerShell.Window.keyboardInteractivity: LayerShell.Window.KeyboardInteractivityNone
}
